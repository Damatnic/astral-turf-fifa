// This prompt file is loaded by aiService.ts and is no longer a placeholder. It is intentionally left blank for removal in final cleanup.
