Based on the following player data, write a short, creative, and evocative biography for their scout notes. Focus on their playing style and potential.
- Name: {{PLAYER_NAME}}
- Age: {{PLAYER_AGE}}
- Nationality: {{PLAYER_NATIONALITY}}
- Role: {{PLAYER_ROLE}}
- Key Attributes: {{PLAYER_ATTRIBUTES}}
- Traits: {{PLAYER_TRAITS}}
